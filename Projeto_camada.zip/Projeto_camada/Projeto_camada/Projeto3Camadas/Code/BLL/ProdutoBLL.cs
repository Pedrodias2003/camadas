﻿using System.Data;


using Projeto3Camadas.Code.DTO; 
using Projeto3Camadas.Code.DAL; 


namespace Projeto3Camadas.Code.BLL
{
    class ProdutoBLL
    {

        
        AcessoBancoDados conexao = new AcessoBancoDados();
        string tabela = "Produto";


        
        public void Inserir (ProdutoDTO ProdutoDto)
        {
           
            string inserir = $"insert into {tabela} values('{ProdutoDto.Id}','{ProdutoDto.Nome}','{ProdutoDto.Genero}')";
            conexao.ExecutarComando(inserir);
        }

        public DataTable Listar()     
        {
            string sql = $"select * from {tabela} order by id;";
            return conexao.ExecutarConsulta(sql);
        }

        public void Editar(ProdutoDTO ProdutoDto)
        {
            string alterar = $"update {tabela} set nome = '{ProdutoDto.Nome}', genero = '{ProdutoDto.Genero}' where id = '{ProdutoDto.Id}';";
            conexao.ExecutarComando(alterar);
        }


        public void Excluir(ProdutoDTO ProdutoDto)
        {
            string excluir = $"delete from {tabela} where id = '{ProdutoDto.Id}';";
            conexao.ExecutarComando(excluir);
        }
    }
}
